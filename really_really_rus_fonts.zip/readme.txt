"Really? Really!" Russian font made by RikuKH3.

Typeface is 'Minion Pro Semibold' (Minion Pro SmBd)
